const navToggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector(".nav-menu");
if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => navMenu.classList.toggle("active"));
}

document.querySelectorAll(".faq-item button").forEach((button) => {
    button.addEventListener("click", () => {
        button.closest(".faq-item").classList.toggle("active");
    });
});

const backTop = document.querySelector(".back-top");
if (backTop) {
    window.addEventListener("scroll", () => {
        backTop.classList.toggle("visible", window.scrollY > 500);
    });
    backTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

document.querySelectorAll(".quote-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        const data = new FormData(form);
        const message = [
            "New Enquiry - SPI Secure Solutions",
            "",
            `Name: ${data.get("name") || ""}`,
            `Phone: ${data.get("phone") || ""}`,
            `Location: ${data.get("location") || ""}`,
            `Service: ${data.get("service") || ""}`,
            `Message: ${data.get("message") || ""}`
        ].join("\n");
        window.open(`https://wa.me/919603998358?text=${encodeURIComponent(message)}`, "_blank", "noopener");
        form.reset();
    });
});